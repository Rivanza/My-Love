/**
 * ====================================================================
 * ROMANTIC WEBSITE INTERACTIVE ENGINE
 * ====================================================================
 * Author: Antigravity Romantic Web App
 * Features:
 *  - Floating Particle & Heart Canvas with Mouse Bloom
 *  - Dual-mode Music Engine (Custom MP3 + Built-in Web Audio Chime Synth)
 *  - Real-Time Love Counter (Days, Hours, Minutes, Seconds)
 *  - 3D Wax-Sealed Envelope Animation & Love Letter Modal
 *  - Interactive 3D Flip Cards (Reasons Why I Love You)
 *  - Polaroid Photo Gallery & Lightbox
 *  - The Love Jar (Random romantic notes capsule)
 *  - Dodging "Gak Mau" Button & Confetti Proposal Finale
 *  - In-browser Customizer Settings (saved to localStorage)
 * ====================================================================
 */

document.addEventListener('DOMContentLoaded', () => {
  // Initialize Lucide Icons
  if (window.lucide) {
    window.lucide.createIcons();
  }

  // Load custom configuration from localStorage if available
  initLocalConfig();

  // Initialize Theme Switcher (Rose / Midnight)
  initThemeToggle();

  // Populate dynamic text from config
  renderDynamicContent();

  // Initialize Modules
  initBackgroundCanvas();
  initMusicPlayer();
  initLoveCounter();
  initInteractiveEnvelope();
  initReasonsGrid();
  initMemoriesGallery();
  initLoveJar();
  initProposalSection();
  initSettingsModal();
});

/* ====================================================================
   THEME SWITCHER (TAMPILAN 1: SOFT ROSE & TAMPILAN 2: MIDNIGHT STARLIGHT)
   ==================================================================== */
function initThemeToggle() {
  const btnToggle = document.getElementById('btn-theme-toggle');
  const themeIcon = document.getElementById('theme-icon');
  const themeLabel = document.getElementById('theme-label');

  // Check saved theme or default to rose
  const savedTheme = localStorage.getItem('romantic_web_theme') || 'rose';

  function applyTheme(theme) {
    if (theme === 'midnight') {
      document.body.classList.add('theme-midnight');
      if (themeIcon) themeIcon.textContent = '🌌';
      if (themeLabel) themeLabel.textContent = 'Midnight';
    } else {
      document.body.classList.remove('theme-midnight');
      if (themeIcon) themeIcon.textContent = '🌸';
      if (themeLabel) themeLabel.textContent = 'Rose';
    }
    localStorage.setItem('romantic_web_theme', theme);
  }

  applyTheme(savedTheme);

  if (btnToggle) {
    btnToggle.addEventListener('click', () => {
      const isMidnight = document.body.classList.contains('theme-midnight');
      applyTheme(isMidnight ? 'rose' : 'midnight');

      // Pop micro confetti on theme change
      if (window.confetti) {
        confetti({
          particleCount: 12,
          spread: 40,
          origin: { y: 0.1, x: 0.85 }
        });
      }
    });
  }
}

/* ====================================================================
   1. LOCAL CONFIGURATION & DYNAMIC CONTENT RENDERER
   ==================================================================== */
function initLocalConfig() {
  const savedConfig = localStorage.getItem('romantic_web_config');
  if (savedConfig) {
    try {
      const parsed = JSON.parse(savedConfig);
      if (parsed.nickname) CONFIG.nickname = parsed.nickname;
      if (parsed.anniversaryDate) CONFIG.anniversaryDate = parsed.anniversaryDate;
      if (parsed.yourName) CONFIG.yourName = parsed.yourName;
    } catch (e) {
      console.warn('Error loading custom config:', e);
    }
  }
}

function renderDynamicContent() {
  // Top brand & Hero
  const brand = document.getElementById('nav-brand');
  if (brand) brand.textContent = `Special for ${CONFIG.nickname}`;

  const heroBadge = document.getElementById('hero-badge');
  if (heroBadge) heroBadge.textContent = `Untuk ${CONFIG.nickname} Kesayanganku`;

  const footerNick = document.getElementById('footer-nickname');
  if (footerNick) footerNick.textContent = CONFIG.nickname;

  // Counter Section Titles
  const counterTitle = document.getElementById('counter-title');
  if (counterTitle && CONFIG.counterTitle) counterTitle.textContent = CONFIG.counterTitle;

  const counterSubtitle = document.getElementById('counter-subtitle');
  if (counterSubtitle && CONFIG.counterSubtitle) counterSubtitle.textContent = CONFIG.counterSubtitle;

  // Letter Modal Texts
  const letterBadge = document.getElementById('modal-letter-badge');
  if (letterBadge && CONFIG.letter?.badge) letterBadge.textContent = CONFIG.letter.badge;

  const letterTitle = document.getElementById('modal-letter-title');
  if (letterTitle && CONFIG.letter?.title) letterTitle.textContent = CONFIG.letter.title;

  const letterDate = document.getElementById('modal-letter-date');
  if (letterDate && CONFIG.letter?.date) letterDate.textContent = CONFIG.letter.date;

  const letterClosing = document.getElementById('modal-letter-closing');
  if (letterClosing && CONFIG.letter?.closing) letterClosing.textContent = CONFIG.letter.closing;

  const letterSig = document.getElementById('modal-letter-signature');
  if (letterSig && CONFIG.letter?.signature) letterSig.textContent = CONFIG.letter.signature;

  // Proposal Texts
  const proposalQ = document.getElementById('proposal-question');
  if (proposalQ && CONFIG.proposal?.question) proposalQ.textContent = CONFIG.proposal.question;

  const proposalSub = document.getElementById('proposal-subtext');
  if (proposalSub && CONFIG.proposal?.subtext) proposalSub.textContent = CONFIG.proposal.subtext;

  const proposalYes = document.getElementById('proposal-yes-text');
  if (proposalYes && CONFIG.proposal?.yesButtonText) proposalYes.textContent = CONFIG.proposal.yesButtonText;

  const proposalNo = document.getElementById('proposal-no-text');
  if (proposalNo && CONFIG.proposal?.noButtonText) proposalNo.textContent = CONFIG.proposal.noButtonText;

  const successTitle = document.getElementById('success-title');
  if (successTitle && CONFIG.proposal?.successTitle) successTitle.textContent = CONFIG.proposal.successTitle;

  const successMsg = document.getElementById('success-message');
  if (successMsg && CONFIG.proposal?.successMessage) successMsg.textContent = CONFIG.proposal.successMessage;

  // WhatsApp Button Link
  const btnWA = document.getElementById('btn-whatsapp');
  if (btnWA && CONFIG.proposal?.whatsappMessage) {
    const encoded = encodeURIComponent(CONFIG.proposal.whatsappMessage);
    btnWA.href = `https://api.whatsapp.com/send?text=${encoded}`;
  }
}

/* ====================================================================
   2. BACKGROUND PARTICLES & FLOATING HEARTS CANVAS
   ==================================================================== */
function initBackgroundCanvas() {
  const canvas = document.getElementById('bg-canvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');

  let width = (canvas.width = window.innerWidth);
  let height = (canvas.height = window.innerHeight);

  window.addEventListener('resize', () => {
    width = canvas.width = window.innerWidth;
    height = canvas.height = window.innerHeight;
  });

  const particles = [];
  const particleCount = Math.min(Math.floor(window.innerWidth / 25), 45);

  const colorsRose = [
    'rgba(244, 63, 94, 0.45)', // Rose-500
    'rgba(251, 113, 133, 0.4)', // Rose-400
    'rgba(254, 205, 211, 0.5)', // Rose-200
    'rgba(225, 29, 72, 0.35)',  // Rose-600
    'rgba(253, 164, 175, 0.4)'  // Rose-300
  ];

  const colorsMidnight = [
    'rgba(251, 113, 133, 0.75)', // Neon Rose
    'rgba(232, 121, 249, 0.7)',  // Fuchsia
    'rgba(192, 132, 252, 0.65)', // Purple
    'rgba(254, 240, 138, 0.85)', // Starlight Gold
    'rgba(244, 63, 94, 0.7)'     // Glowing Rose
  ];

  class Particle {
    constructor(x, y, isBurst = false) {
      const isMidnight = document.body.classList.contains('theme-midnight');
      const palette = isMidnight ? colorsMidnight : colorsRose;

      this.x = x ?? Math.random() * width;
      this.y = y ?? (isBurst ? y : Math.random() * height);
      this.size = isBurst ? Math.random() * 14 + 10 : Math.random() * 12 + 6;
      this.speedY = isBurst ? (Math.random() - 0.5) * 4 : -(Math.random() * 0.8 + 0.3);
      this.speedX = (Math.random() - 0.5) * (isBurst ? 4 : 0.8);
      this.color = palette[Math.floor(Math.random() * palette.length)];
      this.alpha = isBurst ? 1 : Math.random() * 0.6 + 0.2;
      this.fadeSpeed = isBurst ? 0.02 : 0;
      this.angle = Math.random() * Math.PI * 2;
      this.spin = (Math.random() - 0.5) * 0.02;
      this.isHeart = Math.random() > 0.35 || isBurst;
    }

    update() {
      this.x += this.speedX;
      this.y += this.speedY;
      this.angle += this.spin;

      if (this.fadeSpeed > 0) {
        this.alpha -= this.fadeSpeed;
      } else {
        if (this.y < -30) {
          this.y = height + 30;
          this.x = Math.random() * width;
        }
      }
    }

    draw() {
      ctx.save();
      ctx.translate(this.x, this.y);
      ctx.rotate(this.angle);
      ctx.globalAlpha = Math.max(0, this.alpha);

      if (this.isHeart) {
        // Draw Heart Shape
        ctx.fillStyle = this.color;
        ctx.beginPath();
        const topCurveHeight = this.size * 0.3;
        ctx.moveTo(0, topCurveHeight);
        ctx.bezierCurveTo(0, 0, -this.size / 2, 0, -this.size / 2, topCurveHeight);
        ctx.bezierCurveTo(-this.size / 2, (this.size + topCurveHeight) / 2, 0, this.size, 0, this.size * 1.25);
        ctx.bezierCurveTo(0, this.size, this.size / 2, (this.size + topCurveHeight) / 2, this.size / 2, topCurveHeight);
        ctx.bezierCurveTo(this.size / 2, 0, 0, 0, 0, topCurveHeight);
        ctx.closePath();
        ctx.fill();
      } else {
        // Draw Soft Glowing Orb / Starlight
        ctx.fillStyle = this.color;
        ctx.beginPath();
        ctx.arc(0, 0, this.size / 2, 0, Math.PI * 2);
        ctx.fill();
      }

      ctx.restore();
    }
  }

  // Populate floating particles
  for (let i = 0; i < particleCount; i++) {
    particles.push(new Particle());
  }

  // Burst on click / touch
  function spawnBurst(e) {
    const clientX = e.clientX || (e.touches && e.touches[0]?.clientX);
    const clientY = e.clientY || (e.touches && e.touches[0]?.clientY);
    if (!clientX || !clientY) return;

    for (let i = 0; i < 6; i++) {
      particles.push(new Particle(clientX, clientY, true));
    }
  }

  window.addEventListener('click', spawnBurst);

  // Animation Loop
  function animate() {
    ctx.clearRect(0, 0, width, height);

    for (let i = particles.length - 1; i >= 0; i--) {
      const p = particles[i];
      p.update();
      p.draw();

      // Clean up burst particles that faded out
      if (p.fadeSpeed > 0 && p.alpha <= 0) {
        particles.splice(i, 1);
      }
    }

    requestAnimationFrame(animate);
  }

  animate();
}

/* ====================================================================
   3. MUSIC PLAYER (AUDIO + BUILT-IN FALLBACK SYNTHESIZER)
   ==================================================================== */
function initMusicPlayer() {
  const audio = document.getElementById('bg-audio');
  const btnToggle = document.getElementById('btn-music-toggle');
  const vinylIcon = document.getElementById('vinyl-icon');
  const musicText = document.getElementById('music-text');
  const soundBars = document.getElementById('sound-bars');

  let isPlaying = false;
  let synthAudioCtx = null;
  let synthInterval = null;

  if (CONFIG.music?.url && audio) {
    audio.src = CONFIG.music.url;
  }

  // Romantic gentle chime synth fallback (Web Audio API)
  function startChimeSynth() {
    try {
      if (!synthAudioCtx) {
        const AudioContextClass = window.AudioContext || window.webkitAudioContext;
        synthAudioCtx = new AudioContextClass();
      }
      if (synthAudioCtx.state === 'suspended') {
        synthAudioCtx.resume();
      }

      const notes = [261.63, 329.63, 392.00, 440.00, 523.25, 587.33, 659.25]; // C, E, G, A, C5, D5, E5
      let step = 0;

      function playNote() {
        if (!isPlaying || !synthAudioCtx) return;
        const osc = synthAudioCtx.createOscillator();
        const gain = synthAudioCtx.createGain();

        const freq = notes[step % notes.length];
        step++;

        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, synthAudioCtx.currentTime);

        gain.gain.setValueAtTime(0.01, synthAudioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.08, synthAudioCtx.currentTime + 0.2);
        gain.gain.exponentialRampToValueAtTime(0.001, synthAudioCtx.currentTime + 2.2);

        osc.connect(gain);
        gain.connect(synthAudioCtx.destination);

        osc.start();
        osc.stop(synthAudioCtx.currentTime + 2.3);
      }

      playNote();
      synthInterval = setInterval(playNote, 1800);
    } catch (err) {
      console.warn('Web Audio Synth could not start:', err);
    }
  }

  function stopChimeSynth() {
    if (synthInterval) {
      clearInterval(synthInterval);
      synthInterval = null;
    }
  }

  function playMusic() {
    isPlaying = true;
    if (vinylIcon) vinylIcon.classList.add('playing');
    if (soundBars) soundBars.classList.remove('hidden');
    if (musicText) musicText.textContent = CONFIG.music?.title || 'Lover';

    if (audio && audio.src) {
      audio.play().catch(() => {
        // If external audio blocked or fails, use gentle romantic Web Audio Synth!
        startChimeSynth();
      });
    } else {
      startChimeSynth();
    }
  }

  function pauseMusic() {
    isPlaying = false;
    if (vinylIcon) vinylIcon.classList.remove('playing');
    if (soundBars) soundBars.classList.add('hidden');
    if (musicText) musicText.textContent = 'Putar Musik';

    if (audio) audio.pause();
    stopChimeSynth();
  }

  if (btnToggle) {
    btnToggle.addEventListener('click', (e) => {
      e.stopPropagation();
      if (isPlaying) {
        pauseMusic();
      } else {
        playMusic();
      }
    });
  }

  // Gentle autoplay prompt on first user click anywhere on screen
  let userInteracted = false;
  function handleFirstInteraction() {
    if (!userInteracted) {
      userInteracted = true;
      if (!isPlaying) {
        playMusic();
      }
    }
  }

  window.addEventListener('click', handleFirstInteraction, { once: true });
  window.addEventListener('touchstart', handleFirstInteraction, { once: true });
}

/* ====================================================================
   4. REAL-TIME LOVE COUNTER
   ==================================================================== */
function initLoveCounter() {
  const elDays = document.getElementById('counter-days');
  const elHours = document.getElementById('counter-hours');
  const elMinutes = document.getElementById('counter-minutes');
  const elSeconds = document.getElementById('counter-seconds');

  if (!elDays || !elHours || !elMinutes || !elSeconds) return;

  function updateCounter() {
    const targetDate = new Date(CONFIG.anniversaryDate).getTime();
    const now = new Date().getTime();
    let diff = now - targetDate;

    // In case targetDate is in the future (countdown instead of count-up)
    if (diff < 0) {
      diff = Math.abs(diff);
    }

    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((diff % (1000 * 60)) / 1000);

    elDays.textContent = days.toLocaleString('id-ID');
    elHours.textContent = String(hours).padStart(2, '0');
    elMinutes.textContent = String(minutes).padStart(2, '0');
    elSeconds.textContent = String(seconds).padStart(2, '0');
  }

  updateCounter();
  setInterval(updateCounter, 1000);
}

/* ====================================================================
   5. INTERACTIVE 3D ENVELOPE & LOVE LETTER MODAL
   ==================================================================== */
function initInteractiveEnvelope() {
  const envelope = document.getElementById('interactive-envelope');
  const letterModal = document.getElementById('letter-modal');
  const btnClose = document.getElementById('btn-close-letter');
  const letterBody = document.getElementById('modal-letter-body');

  if (!envelope || !letterModal) return;

  // Render paragraphs from CONFIG.letter.paragraphs
  if (letterBody && CONFIG.letter?.paragraphs) {
    letterBody.innerHTML = CONFIG.letter.paragraphs
      .map((p) => `<p>${p}</p>`)
      .join('');
  }

  function openLetter() {
    envelope.classList.add('open');

    // Trigger sweet heart confetti
    if (window.confetti) {
      confetti({
        particleCount: 25,
        spread: 60,
        origin: { y: 0.6 }
      });
    }

    setTimeout(() => {
      letterModal.classList.remove('opacity-0', 'pointer-events-none');
      letterModal.classList.add('active');
    }, 550);
  }

  function closeLetter() {
    letterModal.classList.add('opacity-0', 'pointer-events-none');
    letterModal.classList.remove('active');
    setTimeout(() => {
      envelope.classList.remove('open');
    }, 300);
  }

  envelope.addEventListener('click', openLetter);
  if (btnClose) btnClose.addEventListener('click', closeLetter);

  // Close when clicking modal backdrop
  letterModal.addEventListener('click', (e) => {
    if (e.target === letterModal) closeLetter();
  });
}

/* ====================================================================
   6. 3D FLIP CARDS (REASONS WHY I LOVE YOU)
   ==================================================================== */
function initReasonsGrid() {
  const container = document.getElementById('reasons-grid');
  if (!container || !CONFIG.reasons) return;

  container.innerHTML = CONFIG.reasons
    .map((reason, index) => {
      return `
      <div class="flip-card" data-index="${index}">
        <div class="flip-card-inner">
          <!-- Front -->
          <div class="flip-card-front">
            <span class="text-4xl mb-3">${reason.icon || '💖'}</span>
            <h4 class="font-serif text-xl font-bold text-rose-950 mb-1">${reason.title}</h4>
            <span class="text-xs text-rose-500 font-medium flex items-center gap-1 mt-2">
              <i data-lucide="sparkle" class="w-3.5 h-3.5"></i>
              Sentuh untuk melihat rahasia
            </span>
          </div>
          <!-- Back -->
          <div class="flip-card-back">
            <h5 class="font-serif text-lg font-bold text-rose-900 mb-2">${reason.title}</h5>
            <p class="text-xs sm:text-sm text-stone-700 leading-relaxed font-light">${reason.desc}</p>
          </div>
        </div>
      </div>
      `;
    })
    .join('');

  if (window.lucide) window.lucide.createIcons();

  // Mobile tap support for flipping
  const cards = container.querySelectorAll('.flip-card');
  cards.forEach((card) => {
    card.addEventListener('click', () => {
      card.classList.toggle('flipped');
    });
  });
}

/* ====================================================================
   7. POLAROID MEMORIES GALLERY & LIGHTBOX
   ==================================================================== */
function initMemoriesGallery() {
  const container = document.getElementById('memories-grid');
  const photoModal = document.getElementById('photo-modal');
  const modalImg = document.getElementById('modal-photo-img');
  const modalCaption = document.getElementById('modal-photo-caption');
  const btnClosePhoto = document.getElementById('btn-close-photo');

  if (!container || !CONFIG.memories) return;

  container.innerHTML = CONFIG.memories
    .map((mem) => {
      return `
      <div class="polaroid cursor-pointer group" data-img="${mem.image}" data-caption="${mem.caption}">
        <div class="overflow-hidden rounded bg-rose-50 aspect-square mb-3">
          <img src="${mem.image}" alt="${mem.caption}" loading="lazy" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500">
        </div>
        <p class="font-hand text-xl font-bold text-rose-900 truncate">${mem.caption}</p>
        <span class="text-[11px] font-medium text-stone-400 block mt-0.5">${mem.date || 'Memori Berharga'}</span>
      </div>
      `;
    })
    .join('');

  const polaroids = container.querySelectorAll('.polaroid');
  polaroids.forEach((pol) => {
    pol.addEventListener('click', () => {
      const src = pol.getAttribute('data-img');
      const caption = pol.getAttribute('data-caption');
      if (modalImg && modalCaption && photoModal) {
        modalImg.src = src;
        modalCaption.textContent = caption;
        photoModal.classList.remove('opacity-0', 'pointer-events-none');
      }
    });
  });

  function closePhoto() {
    if (photoModal) {
      photoModal.classList.add('opacity-0', 'pointer-events-none');
    }
  }

  if (btnClosePhoto) btnClosePhoto.addEventListener('click', closePhoto);
  if (photoModal) {
    photoModal.addEventListener('click', (e) => {
      if (e.target === photoModal) closePhoto();
    });
  }
}

/* ====================================================================
   8. LOVE JAR (KAPSUL KATA-KATA MANIS)
   ==================================================================== */
function initLoveJar() {
  const btnJar = document.getElementById('btn-love-jar');
  const noteBox = document.getElementById('jar-note-box');
  const noteText = document.getElementById('jar-note-text');
  const btnAgain = document.getElementById('btn-jar-again');

  if (!btnJar || !noteBox || !noteText) return;

  const notes = CONFIG.loveNotes || [];
  let lastIndex = -1;

  function pullNote() {
    if (notes.length === 0) return;
    let randomIndex;
    do {
      randomIndex = Math.floor(Math.random() * notes.length);
    } while (notes.length > 1 && randomIndex === lastIndex);

    lastIndex = randomIndex;
    noteText.textContent = `"${notes[randomIndex]}"`;

    noteBox.classList.remove('hidden');
    noteBox.classList.add('animate-float');

    // Pop tiny heart confetti
    if (window.confetti) {
      confetti({
        particleCount: 15,
        spread: 45,
        origin: { y: 0.7 }
      });
    }
  }

  btnJar.addEventListener('click', pullNote);
  if (btnAgain) btnAgain.addEventListener('click', pullNote);
}

/* ====================================================================
   9. PROPOSAL FINALE (DODGING NO BUTTON & CONFETTI YES BUTTON)
   ==================================================================== */
function initProposalSection() {
  const btnYes = document.getElementById('btn-yes');
  const btnNo = document.getElementById('btn-no');
  const successModal = document.getElementById('success-modal');
  const btnCloseSuccess = document.getElementById('btn-close-success');

  if (!btnYes || !btnNo) return;

  const teasingPhrases = [
    'Yakin nih? 🥺',
    'Eits, gabisa diklik! 😜',
    'Harus mau dong! ❤️',
    'Coba klik yang merah aja! 🥰',
    'Gak ada pilihan gak mau ya 🙈',
    'Jangan kabur dong manis! ✨'
  ];
  let phraseIndex = 0;

  // Dodge function
  function dodgeButton(e) {
    e.preventDefault();

    const parent = btnNo.parentElement;
    const parentRect = parent.getBoundingClientRect();
    const btnRect = btnNo.getBoundingClientRect();

    // Calculate maximum safe bounds inside parent
    const maxOffsetX = parentRect.width - btnRect.width;
    const maxOffsetY = 140;

    const randomX = (Math.random() - 0.5) * (maxOffsetX * 0.8);
    const randomY = (Math.random() - 0.5) * maxOffsetY;

    btnNo.style.transform = `translate(${randomX}px, ${randomY}px)`;

    // Change text playfully
    const noTextEl = document.getElementById('proposal-no-text');
    if (noTextEl) {
      noTextEl.textContent = teasingPhrases[phraseIndex % teasingPhrases.length];
      phraseIndex++;
    }
  }

  btnNo.addEventListener('mouseenter', dodgeButton);
  btnNo.addEventListener('touchstart', dodgeButton, { passive: false });
  btnNo.addEventListener('click', dodgeButton);

  // YES Button Click
  btnYes.addEventListener('click', () => {
    // Grand Confetti Fireworks
    if (window.confetti) {
      const end = Date.now() + 4 * 1000;
      const colors = ['#f43f5e', '#fb7185', '#fda4af', '#fcd34d', '#ffffff'];

      (function frame() {
        confetti({
          particleCount: 5,
          angle: 60,
          spread: 55,
          origin: { x: 0 },
          colors: colors
        });
        confetti({
          particleCount: 5,
          angle: 120,
          spread: 55,
          origin: { x: 1 },
          colors: colors
        });

        if (Date.now() < end) {
          requestAnimationFrame(frame);
        }
      })();
    }

    // Show Success Modal
    if (successModal) {
      setTimeout(() => {
        successModal.classList.remove('opacity-0', 'pointer-events-none');
      }, 500);
    }
  });

  if (btnCloseSuccess && successModal) {
    btnCloseSuccess.addEventListener('click', () => {
      successModal.classList.add('opacity-0', 'pointer-events-none');
    });
  }
}

/* ====================================================================
   10. SETTINGS & CUSTOMIZER MODAL
   ==================================================================== */
function initSettingsModal() {
  const btnOpen = document.getElementById('btn-open-settings');
  const modal = document.getElementById('settings-modal');
  const btnClose = document.getElementById('btn-close-settings');
  const form = document.getElementById('settings-form');
  const btnReset = document.getElementById('btn-reset-settings');

  const inputNickname = document.getElementById('input-nickname');
  const inputAnniversary = document.getElementById('input-anniversary');
  const inputYourName = document.getElementById('input-yourname');

  if (!btnOpen || !modal) return;

  function openSettings() {
    if (inputNickname) inputNickname.value = CONFIG.nickname || '';
    if (inputAnniversary) inputAnniversary.value = CONFIG.anniversaryDate || '';
    if (inputYourName) inputYourName.value = CONFIG.yourName || '';
    modal.classList.remove('opacity-0', 'pointer-events-none');
  }

  function closeSettings() {
    modal.classList.add('opacity-0', 'pointer-events-none');
  }

  btnOpen.addEventListener('click', openSettings);
  if (btnClose) btnClose.addEventListener('click', closeSettings);

  if (modal) {
    modal.addEventListener('click', (e) => {
      if (e.target === modal) closeSettings();
    });
  }

  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const newConfig = {
        nickname: inputNickname.value.trim() || CONFIG.nickname,
        anniversaryDate: inputAnniversary.value || CONFIG.anniversaryDate,
        yourName: inputYourName.value.trim() || CONFIG.yourName
      };

      localStorage.setItem('romantic_web_config', JSON.stringify(newConfig));
      CONFIG.nickname = newConfig.nickname;
      CONFIG.anniversaryDate = newConfig.anniversaryDate;
      CONFIG.yourName = newConfig.yourName;

      renderDynamicContent();
      closeSettings();
    });
  }

  if (btnReset) {
    btnReset.addEventListener('click', () => {
      localStorage.removeItem('romantic_web_config');
      location.reload();
    });
  }
}

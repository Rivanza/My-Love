/**
 * ====================================================================
 * PENGATURAN KONTEN WEBSITE ROMANTIS
 * ====================================================================
 * Kamu bisa dengan mudah mengubah nama, tanggal, pesan, dan foto-foto
 * di file ini tanpa perlu mengutak-atik kode HTML yang rumit!
 */

const CONFIG = {
  // Informasi Pasangan / Orang Tersayang
  nickname: "Sayang", // Nama panggilan untuk si dia (contoh: Sayang, Ayang, Cantik, [Nama Pacar])
  fullName: "Adinda Putri", // Nama lengkap / panggilan lengkap
  yourName: "Aku yang selalu mencintaimu", // Nama kamu / panggilan kamu

  // Tanggal penting (Bisa tanggal jadian, tanggal pertama ketemu, atau PDKT)
  // Format: YYYY-MM-DDTHH:MM:SS
  anniversaryDate: "2024-02-14T00:00:00", 
  counterTitle: "Hari-Hari Indah Bersamamu",
  counterSubtitle: "Setiap detik bersamamu adalah anugerah terindah",

  // Musik Latar Belakang
  // Bisa gunakan link audio mp3 online atau file lokal di folder yang sama (contoh: "music.mp3")
  music: {
    title: "Until I Found You",
    artist: "Stephen Sanchez",
    // Link audio mp3 romantis (default instrumental piano yang lembut)
    url: "https://cdn.pixabay.com/download/audio/2022/05/27/audio_1808fbf07a.mp3?filename=romantic-piano-112199.mp3",
    autoplayPrompt: true // Tampilkan tombol putar musik di awal agar tidak diblokir browser
  },

  // Surat Cinta Utama (Didalam Amplop Interaktif)
  letter: {
    badge: "Surat Khusus Untukmu 💌",
    title: "Untuk Kamu, Duniaku",
    date: "Hari Ini & Selamanya",
    paragraphs: [
      "Sejak hari pertama kamu hadir di hidupku, semuanya terasa jauh lebih berwarna. Cara kamu tersenyum, caramu tertawa, bahkan hal-hal kecil yang kamu ceritakan selalu berhasil membuat hariku jadi lebih baik.",
      "Mungkin aku bukan orang yang paling pandai merangkai kata-kata puitis, tapi ada satu hal yang pasti: aku selalu bersyukur semesta mempertemukan kita. Kamu adalah tempat pulang paling nyaman dari riuhnya dunia.",
      "Terima kasih sudah bertahan, terima kasih sudah selalu ada dengan segala kehangatan dan ketulusanmu. Aku berjanji akan selalu berusaha membuatmu tersenyum setiap harinya.",
      "Aku sayang kamu, hari ini, esok, dan seterusnya. ❤️"
    ],
    closing: "Dengan segenap hatiku,",
    signature: "Yours Sincerely 💕"
  },

  // 6 Alasan Mengapa Aku Mencintaimu (Kartu 3D Flip)
  reasons: [
    {
      icon: "✨",
      title: "Senyuman Manismu",
      desc: "Senyummu itu punya sihir tersendiri. Seberat apapun hariku, melihatmu tersenyum langsung bikin semuanya terasa tenang."
    },
    {
      icon: "💖",
      title: "Hati yang Tulus & Lembut",
      desc: "Kebaikan hatimu dan caramu memperlakukan orang lain selalu membuatku kagum dan semakin jatuh cinta."
    },
    {
      icon: "🎧",
      title: "Pendengar Terbaik",
      desc: "Kamu selalu mau mendengarkan keluh kesah dan ceritaku yang kadang gak penting, tanpa pernah menghakimi."
    },
    {
      icon: "🌸",
      title: "Jadi Diri Sendiri",
      desc: "Saat bersamamu, aku merasa bisa menjadi diriku yang seutuhnya tanpa rasa takut atau ragu."
    },
    {
      icon: "☕",
      title: "Momen Kecil Berharga",
      desc: "Mulai dari ngobrol larut malam, bercanda hal random, hingga diam berdua... semuanya terasa sangat berharga."
    },
    {
      icon: "🌙",
      title: "Masa Depan Bersamamu",
      desc: "Melihat masa depan bersamamu terasa menenangkan. Aku ingin melangkah melewati banyak hal bersamamu."
    }
  ],

  // Galeri Kenangan Polaroid (Bisa diganti foto kalian berdua)
  memories: [
    {
      image: "https://images.unsplash.com/photo-1518199266791-5375a83190b7?q=80&w=800&auto=format&fit=crop",
      caption: "Pertama kali kita jalan bareng",
      date: "Momen Tak Terlupakan"
    },
    {
      image: "https://images.unsplash.com/photo-1529333166437-7750a6dd5a70?q=80&w=800&auto=format&fit=crop",
      caption: "Tawa lepas yang selalu kurindukan",
      date: "Kenangan Manis"
    },
    {
      image: "https://images.unsplash.com/photo-1516589178581-6cd7833ae3b2?q=80&w=800&auto=format&fit=crop",
      caption: "Bergandengan tangan melihat senja",
      date: "Sunset Indah"
    },
    {
      image: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=800&auto=format&fit=crop",
      caption: "Wajah cantikmu yang bikin salting",
      date: "Favoritku"
    }
  ],

  // Kapsul Pesan Cinta (Love Jar)
  // Pesan-pesan acak saat toples cinta diklik
  loveNotes: [
    "Jangan lupa makan ya hari ini, kamu harus selalu sehat! 🥰",
    "Ingat, kalau kamu lagi capek, aku selalu ada di sini buat dengerin kamu.",
    "Bumi itu bulat, tapi cintaku padamu tak berujung. Eaa! 🙈",
    "Kamu itu kayak kopi pagi hari, selalu bikin hari-hariku bersemangat! ☕",
    "Terima kasih sudah lahir ke dunia dan menjadi bagian dari hidupku.",
    "Kalau ada lomba orang tercantik dan termanis, kamu pasti juaranya seumur hidup!",
    "Aku bangga banget punya kamu. Kamu hebat sudah melangkah sejauh ini! ✨",
    "Peluk jauh buat kamu yang lagi baca ini! 🤗💖"
  ],

  // Pertanyaan Romantis Interaktif di Bagian Akhir
  proposal: {
    question: "Maukah kamu terus menjadi alasan tersenyumku setiap hari? 💍✨",
    subtext: "Jawab dengan jujur dari lubuk hatimu ya...",
    yesButtonText: "Iya, Mau Banget! 💖",
    noButtonText: "Gak Mau 😜",
    successTitle: "YAAAY! I Love You So Much! 🎉❤️",
    successMessage: "Janji ya kita bakal terus sama-sama, saling jaga, dan melangkah bersama menggapai mimpi-mimpi kita!",
    whatsappMessage: "Aku udah buka web romantis dari kamu! Dan jawabanku... IYA MAU BANGET! 💖🥰"
  }
};
